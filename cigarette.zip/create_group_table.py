import sqlite3

def create_group_table():
    # 连接数据库
    conn = sqlite3.connect('e:\\Temp\\cigarette\\tobacco.db')
    cursor = conn.cursor()
    
    try:
        # 创建groups表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS groups (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_num INTEGER,
                group_name TEXT,
                group_desc TEXT
            )
        ''')
        
        # 提交事务
        conn.commit()
        print("表 groups 创建成功！")
        
    except Exception as e:
        print(f"发生错误: {e}")
    finally:
        # 关闭连接
        conn.close()

def insert_groups_data(group_nums, group_names, group_descs):
    # 连接数据库
    conn = sqlite3.connect('e:\\Temp\\cigarette\\tobacco.db')
    cursor = conn.cursor()
    
    try:
        # 插入数据
        cursor.executemany('''
            INSERT INTO groups (group_num, group_name, group_desc)
            VALUES (?, ?, ?)
        ''', zip(group_nums, group_names, group_descs))
        
        # 提交事务
        conn.commit()
        print(f"成功插入 {len(group_nums)} 条数据到 groups 表！")
        
    except Exception as e:
        print(f"发生错误: {e}")
    finally:
        # 关闭连接
        conn.close()

if __name__ == "__main__":

    group_nums = [12]
    group_names = [
        "江西中烟工业有限责任公司"]
    group_descs = [
        "江西中烟成立于2004年10月28日，是由江西烟草顺应行业工商管理体制改革分设而成，主要负责全省卷烟工业企业的生产经营工作，下辖南昌卷烟厂、赣南卷烟厂、广丰卷烟厂、井冈山卷烟厂、兴国卷烟厂等五家烟厂。"]
    insert_groups_data(group_nums, group_names, group_descs)