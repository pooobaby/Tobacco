# 导入必要的库
import sqlite3

# 连接到SQLite数据库（如果不存在则会创建）
conn = sqlite3.connect('tobacco.db')

# 创建一个游标对象
cursor = conn.cursor()

# 创建一个名为cigarettes的表
cursor.execute('''
CREATE TABLE IF NOT EXISTS cigarettes (
    id INTEGER PRIMARY KEY AUTOINCREMENT, -- 香烟记录的唯一标识符
    brand TEXT, -- 品牌
    name TEXT, -- 香烟名称
    number TEXT, -- 香烟编号
    company_name TEXT, -- 公司名称
    company_num TEXT, -- 公司编号
    type TEXT, -- 卷烟类型
    tar TEXT, -- 焦油量
    nicotine TEXT, -- 烟气烟碱量
    co TEXT, -- 一氧化碳含量
    length TEXT, -- 香烟长度
    packaging TEXT, -- 包装形式
    box_count INTEGER, -- 单盒数量
    box_price REAL, -- 单盒价格
    strip_count INTEGER, -- 单条数量
    strip_price REAL, -- 单条价格
    box_code TEXT, -- 盒码
    barcode TEXT, -- 条码
    is_thin TEXT, -- 是否为细支烟
    has_ball TEXT, -- 是否有爆珠
    filter_type TEXT, -- 滤嘴类型
    status TEXT, -- 产品状态
    photo_main TEXT, -- 首页展示用香烟图片链接
    photo_links TEXT -- 所有香烟图片链接
    favorite INTEGER DEFAULT 0 -- 收藏状态，默认为0（未收藏）
)
''')

# 提交更改
conn.commit()

# 关闭连接
conn.close()

print('数据库和表已成功创建。')