import sqlite3

def rename_columns():
    # 连接数据库
    conn = sqlite3.connect('e:\\Temp\\cigarette\\tobacco.db')
    cursor = conn.cursor()
    
    try:
        # 重命名字段
        cursor.execute('ALTER TABLE cigarettes RENAME COLUMN company_name TO group_name')
        cursor.execute('ALTER TABLE cigarettes RENAME COLUMN company_num TO group_num')
        
        # 提交事务
        conn.commit()
        print("字段名修改成功！")
        
    except Exception as e:
        print(f"发生错误: {e}")
    finally:
        # 关闭连接
        conn.close()

if __name__ == "__main__":
    rename_columns()