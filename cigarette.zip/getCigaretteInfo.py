import requests
from bs4 import BeautifulSoup
import json
import time  # 新增导入
import sqlite3

def get_cigarette_info(url):
    # 设置请求头
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
    }
    
    # 发送HTTP请求
    response = requests.get(url, headers=headers)
    response.encoding = 'utf-8'
    
    # 解析HTML内容
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # 获取香烟名称
    name_div = soup.find('div', class_='con0_left01').find('div', style=lambda value: value and 'float:left' in value and 'font-size: 22px' in value)
    name = name_div.text.strip() if name_div else '未知'
    
    # 获取生产厂家
    manufacturer_div = soup.find('div', class_='con0_left01').find('div', style=lambda value: value and 'float:right' in value and 'font-size: 16px' in value)
    manufacturer = manufacturer_div.find('span').text.strip().replace('出品', '') if manufacturer_div else '未知'
    
    # 获取公司编号
    company_num = manufacturer_div.find('a')['href'].split('industryId=')[1] if manufacturer_div and manufacturer_div.find('a') else '未知'
    
    # 获取香烟编号（URL最后几位数字）
    number = url.split('/')[-1].split('.')[0].replace('brand_product_', '')
    
    # 获取卷烟类型
    type_row = soup.find('td', string=lambda x: x and '卷烟类型：' in x)
    cigarette_type = type_row.string.split('：')[-1].strip() if type_row else '未知'
    
    # 获取焦油含量
    tar_row = soup.find('td', string=lambda x: x and '焦油量：' in x)
    tar = tar_row.string.split('：')[-1].strip() if tar_row else '未知'
    
    # 获取烟气烟碱量
    nicotine_row = soup.find('td', string=lambda x: x and '烟气烟碱量：' in x)
    nicotine = nicotine_row.string.split('：')[-1].strip() if nicotine_row else '未知'
    
    # 获取一氧化碳含量
    co_row = soup.find('td', string=lambda x: x and '一氧化碳含量：' in x)
    co = co_row.string.split('：')[-1].strip() if co_row else '未知'
    
    # 获取烟的长度
    length_row = soup.find('td', string=lambda x: x and '烟的长度：' in x)
    length = length_row.string.split('：')[-1].strip() if length_row else '未知'
    
    # 获取包装形式
    packaging_row = soup.find('td', string=lambda x: x and '包装形式：' in x)
    packaging = packaging_row.string.split('：')[-1].strip() if packaging_row else '未知'
    
    # 获取单盒支数
    box_count_row = soup.find('td', string=lambda x: x and '单盒支数：' in x)
    box_count = int(box_count_row.string.split('：')[-1].strip().replace('支', '')) if box_count_row else 0

    # 获取单盒零售指导价
    box_price_row = soup.find('td', string=lambda x: x and '单盒零售指导价：' in x)
    box_price_str = box_price_row.string.split('：')[-1].strip() if box_price_row else '0'
    box_price = float(box_price_str.replace('元', '').replace(',', '')) if box_price_str else 0.00
    
    # 获取单条支数
    strip_count_row = soup.find('td', string=lambda x: x and '单条支数：' in x)
    strip_count = int(strip_count_row.string.split('：')[-1].strip().replace('支', '')) if strip_count_row else 0
    
    # 获取单条零售指导价
    strip_price_row = soup.find('td', string=lambda x: x and '单条零售指导价：' in x)
    strip_price_str = strip_price_row.string.split('：')[-1].strip() if strip_price_row else '0'
    strip_price = float(strip_price_str.replace('元', '').replace(',', '')) if strip_price_str else 0.00
    
    # 获取盒码
    box_code_row = soup.find('td', string=lambda x: x and '盒码：' in x)
    box_code = box_code_row.string.split('：')[-1].strip() if box_code_row else '未知'
    
    # 获取条码
    barcode_row = soup.find('td', string=lambda x: x and '条码：' in x)
    barcode = barcode_row.string.split('：')[-1].strip() if barcode_row else '未知'
    
    # 获取是否细支
    is_thin_row = soup.find('td', string=lambda x: x and '是否细支：' in x)
    is_thin = is_thin_row.string.split('：')[-1].strip() if is_thin_row else '未知'
    
    # 获取是否爆珠
    has_ball_row = soup.find('td', string=lambda x: x and '是否爆珠：' in x)
    has_ball = has_ball_row.string.split('：')[-1].strip() if has_ball_row else '未知'
    
    # 获取滤嘴类型
    filter_type_row = soup.find('td', string=lambda x: x and '滤嘴类型：' in x)
    filter_type = filter_type_row.string.split('：')[-1].strip() if filter_type_row else '未知'
    
    # 获取产品状态
    status_row = soup.find('td', string=lambda x: x and '产品状态：' in x)
    status = status_row.string.split('：')[-1].strip() if status_row else '未知'
    
    # 获取查看所有图片的链接
    all_images_link = 'https://brand.eastobacco.com/queryAllImg.do?brandId=' + number
    
    # 获取所有图片链接
    all_image_links = get_all_image_links(all_images_link)

    # 获取图片链接
    img_div = soup.find('div', style=lambda x: x and 'margin-left: 20px' in x)
    img_src = 'https://brand.eastobacco.com' + img_div.find('img')['src'] if img_div and img_div.find('img') else '未知'

    # 打印结果
    # print(f"香烟名称: {name}")
    # print(f"香烟编号: {number}")
    # print(f"公司编号: {company_num}")
    # print(f"生产厂家: {manufacturer}")
    # print(f"卷烟类型: {cigarette_type}")
    # print(f"焦油含量: {tar}")
    # print(f"烟气烟碱量: {nicotine}")
    # print(f"一氧化碳含量: {co}")
    # print(f"烟的长度: {length}")
    # print(f"包装形式: {packaging}")
    # print(f"单盒支数: {box_count}")
    # print(f"单盒零售指导价: {box_price}")
    # print(f"单条支数: {strip_count}")
    # print(f"单条零售指导价: {strip_price}")
    # print(f"盒码: {box_code}")
    # print(f"条码: {barcode}")
    # print(f"是否细支: {is_thin}")
    # print(f"是否爆珠: {has_ball}")
    # print(f"滤嘴类型: {filter_type}")
    # print(f"产品状态: {status}")
    # print(f"图片链接: {img_src}")
    # print(f"查看所有图片链接: {all_images_link}")
    # print(f"所有图片链接：共{all_image_links.__len__()}张")

    print(f"-- 名称: {name}" + f"  厂家: {manufacturer}" + f"  图片共{all_image_links.__len__()}张")

    # 构建数据字典
    cigarette_data = {
        'brand': brand_name,
        'name': name,
        'number': number,
        'company_name': manufacturer,
        'company_num': company_num,
        'type': cigarette_type,
        'tar': tar,
        'nicotine': nicotine,
        'co': co,
        'length': length,
        'packaging': packaging,
        'box_count': box_count,
        'box_price': box_price,
        'strip_count': strip_count,
        'strip_price': strip_price,
        'box_code': box_code,
        'barcode': barcode,
        'is_thin': is_thin,
        'has_ball': has_ball,
        'filter_type': filter_type,
        'status': status,
        'photo_main': img_src,
        'photo_links': all_image_links
    }
    
    # 保存到数据库
    save_to_db(cigarette_data)
    

def get_all_image_links(all_images_link):
    # 设置请求头
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2',
    }
    
    # 发送HTTP请求
    response = requests.get(all_images_link, headers=headers)
    response.encoding = 'utf-8'
    
    # 解析HTML内容
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # 查找所有图片链接
    image_links = []
    for li in soup.select('ul.ad-thumb-list li'):
        img_tag = li.find('img')
        if img_tag and img_tag.has_attr('src'):
            image_links.append('https://brand.eastobacco.com' + img_tag['src'])
    
    return image_links


def save_to_db(cigarette_data):
    # 连接到SQLite数据库
    conn = sqlite3.connect('e:\\Temp\\cigarette\\tobacco.db')
    cursor = conn.cursor()
    
    # 插入数据
    cursor.execute('''
        INSERT INTO cigarettes (
            brand, name, number, company_name, company_num, type, tar, nicotine, co, 
            length, packaging, box_count, box_price, strip_count, strip_price, 
            box_code, barcode, is_thin, has_ball, filter_type, status, 
            photo_main, photo_links
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        cigarette_data.get('brand'),
        cigarette_data.get('name'),
        cigarette_data.get('number'),
        cigarette_data.get('company_name'),
        cigarette_data.get('company_num'),
        cigarette_data.get('type'),
        cigarette_data.get('tar'),
        cigarette_data.get('nicotine'),
        cigarette_data.get('co'),
        cigarette_data.get('length'),
        cigarette_data.get('packaging'),
        cigarette_data.get('box_count'),
        cigarette_data.get('box_price'),
        cigarette_data.get('strip_count'),
        cigarette_data.get('strip_price'),
        cigarette_data.get('box_code'),
        cigarette_data.get('barcode'),
        cigarette_data.get('is_thin'),
        cigarette_data.get('has_ball'),
        cigarette_data.get('filter_type'),
        cigarette_data.get('status'),
        cigarette_data.get('photo_main'),
        ','.join(cigarette_data.get('photo_links', []))
    ))
    
    # 提交更改并关闭连接
    conn.commit()
    conn.close()


if __name__ == '__main__':
    # 读取brand_links.json
    with open('e:\\Temp\\cigarette\\brand_links.json', 'r', encoding='utf-8') as f:
        brand_links = json.load(f)

    # # 遍历所有品牌
    # for brand_name, links in brand_links.items():
    #     # 只处理宝岛品牌
    #     if brand_name == '宝岛':
    #         # 打印品牌信息
    #         print(f"品牌：{brand_name}")
            
    #         # 获取该品牌的所有链接
    #         for link in links:
    #             url = 'https://brand.eastobacco.com' + link
                
    #             # 爬取香烟信息
    #             get_cigarette_info(url)
                
    #             # 添加延时，避免请求过于频繁
                # time.sleep(2)  # 延时2秒
        
    # 标记是否开始处理
    start_processing = False
    
    for brand_name, links in brand_links.items():
        # 如果遇到黄山品牌，开始处理
        if brand_name == '利群':
            start_processing = True
            
        if start_processing:
            # 打印品牌信息
            print(f"品牌：{brand_name}")
            
            # 获取该品牌的所有链接
            for link in links:
                url = 'https://brand.eastobacco.com' + link
                
                # 爬取香烟信息
                get_cigarette_info(url)
                
                # 添加延时，避免请求过于频繁
                time.sleep(2)  # 延时2秒
            
