import sqlite3

# 连接到SQLite数据库
conn = sqlite3.connect('e:\\Temp\\cigarette\\tobacco.db')

# 创建一个游标对象
cursor = conn.cursor()

# 更新所有记录的favorite字段为0
cursor.execute('UPDATE cigarettes SET favorite = 0')

# 提交更改
conn.commit()

# 关闭连接
conn.close()

print('所有记录的favorite字段已更新为0。')