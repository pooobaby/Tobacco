import sqlite3

def copy_database(source_db, target_db):
    # 连接源数据库
    source_conn = sqlite3.connect(source_db)
    source_cursor = source_conn.cursor()
    
    # 连接目标数据库
    target_conn = sqlite3.connect(target_db)
    target_cursor = target_conn.cursor()
    
    try:
        # 获取源数据库中的所有表名
        source_cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = source_cursor.fetchall()
        
        for table in tables:
            table_name = table[0]
            
            # 跳过系统表
            if table_name == 'sqlite_sequence':
                continue
                
            # 获取表结构
            source_cursor.execute(f"SELECT sql FROM sqlite_master WHERE type='table' AND name='{table_name}';")
            create_table_sql = source_cursor.fetchone()[0]
            
            # 在目标数据库中创建表
            target_cursor.execute(f"DROP TABLE IF EXISTS {table_name};")
            target_cursor.execute(create_table_sql)
            
            # 复制数据
            source_cursor.execute(f"SELECT * FROM {table_name};")
            rows = source_cursor.fetchall()
            
            if rows:
                # 获取列数
                num_columns = len(rows[0])
                placeholders = ','.join(['?'] * num_columns)
                
                # 插入数据
                target_cursor.executemany(f"INSERT INTO {table_name} VALUES ({placeholders});", rows)
        
        # 提交事务
        target_conn.commit()
        print("数据库复制完成！")
        
    except Exception as e:
        print(f"发生错误: {e}")
    finally:
        # 关闭连接
        source_conn.close()
        target_conn.close()

if __name__ == "__main__":
    source_db = "e:\\Temp\\cigarette\\tobacco-2.0.db"
    target_db = "e:\\Temp\\cigarette\\tobacco.db"
    copy_database(source_db, target_db)