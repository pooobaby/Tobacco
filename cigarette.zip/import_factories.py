import sqlite3
import pandas as pd

def import_factories_from_excel():
    # 读取Excel文件
    df = pd.read_excel('e:\\Temp\\cigarette\\factories.xlsx')
    
    # 连接数据库
    conn = sqlite3.connect('e:\\Temp\\cigarette\\tobacco.db')
    cursor = conn.cursor()
    
    try:
        # 插入数据
        cursor.executemany('''
            INSERT INTO factories (group_num, group_name, factory_num, factory_name, factory_desc)
            VALUES (?, ?, ?, ?, ?)
        ''', df.values.tolist())
        
        # 提交事务
        conn.commit()
        print(f"成功插入 {len(df)} 条数据到 factories 表！")
        
    except Exception as e:
        print(f"发生错误: {e}")
    finally:
        # 关闭连接
        conn.close()

if __name__ == "__main__":
    import_factories_from_excel()