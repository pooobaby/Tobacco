import sqlite3

def create_factories_table():
    # 连接数据库
    conn = sqlite3.connect('e:\\Temp\\cigarette\\tobacco.db')
    cursor = conn.cursor()
    
    try:
        # 创建factories表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS factories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_num INTEGER,
                group_name TEXT,
                factory_num INTEGER,
                factory_name TEXT,
                factory_desc TEXT
            )
        ''')
        
        # 提交事务
        conn.commit()
        print("表 factories 创建成功！")
        
    except Exception as e:
        print(f"发生错误: {e}")
    finally:
        # 关闭连接
        conn.close()

if __name__ == "__main__":
    create_factories_table()