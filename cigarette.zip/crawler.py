import requests
from bs4 import BeautifulSoup
import json
import os

def extract_product_links(url):
    n = 1
    product_links = []
    a_url = url.split('pageNum=')[0]
    b_url = url.split('&')[1]
    print(a_url, b_url)
    while True:
        # 拼接完整URL
        page_url = a_url + f"pageNum={n}&" + b_url

        print(f"正在处理第{n}页：{page_url}")
        
        # 发送HTTP请求
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(page_url, headers=headers)
        
        # 检查请求是否成功
        if response.status_code != 200:
            print(f"请求失败，状态码：{response.status_code}")
            break
        
        # 解析HTML内容
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 查找所有目标div
        target_divs = soup.find_all('div', {'class': 'mingyanku_01', 'id': 'mingyanku_01'})
        
        # 如果没有找到内容，终止循环
        if not target_divs:
            print(f"第{n}页没有找到内容，终止爬取")
            break
        
        # 提取产品链接
        for div in target_divs:
            left_div = div.find('div', {'class': 'mingyanku01_left'})
            if left_div:
                link = left_div.find('a')
                if link and 'href' in link.attrs:
                    print(link['href'])
                    product_links.append(link['href'])
        
        # 翻到下一页
        n += 1
    
    return product_links

def main():
    # 从JSON文件读取品牌数据
    with open('e:\\Temp\\cigarette\\cigarettes.json', 'r', encoding='utf-8') as f:
        brands = json.load(f)
    
    brand_links = {}
    
    # 对每个品牌运行爬虫
    for brand in brands:
        print(f"正在处理品牌：{brand['name']}")
        # 拼接完整URL
        base_url = "https://brand.eastobacco.com/"
        url = base_url + brand['link']
        links = extract_product_links(url)
        brand_links[brand['name']] = links
    
    # 将结果保存到JSON文件
    with open('e:\\Temp\\cigarette\\brand_links.json', 'w', encoding='utf-8') as f:
        json.dump(brand_links, f, ensure_ascii=False, indent=4)
    print("品牌链接已保存到brand_links.json")

if __name__ == "__main__":
    main()